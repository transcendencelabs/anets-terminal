"use strict";
var AnetsTerminal = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // src/index.ts
  var index_exports = {};
  __export(index_exports, {
    AnetsTerminal: () => AnetsTerminal,
    AnsiParser: () => AnsiParser,
    BaseBackend: () => BaseBackend,
    Buffer: () => Buffer2,
    DEFAULT_THEME: () => DEFAULT_THEME,
    DRACULA_THEME: () => DRACULA_THEME,
    EraseMode: () => EraseMode,
    FONT_CATALOG: () => FONT_CATALOG,
    ONE_DARK_THEME: () => ONE_DARK_THEME,
    POPULAR_MONOSPACE_FONTS: () => POPULAR_MONOSPACE_FONTS,
    SOLARIZED_DARK_THEME: () => SOLARIZED_DARK_THEME,
    TerminalEvent: () => TerminalEvent,
    WebSocketBackend: () => WebSocketBackend,
    attachWebSocket: () => attachWebSocket,
    createBlankCell: () => createBlankCell,
    mergeTheme: () => mergeTheme
  });

  // src/Types.ts
  var EraseMode = /* @__PURE__ */ ((EraseMode3) => {
    EraseMode3[EraseMode3["ToEnd"] = 0] = "ToEnd";
    EraseMode3[EraseMode3["ToStart"] = 1] = "ToStart";
    EraseMode3[EraseMode3["Entire"] = 2] = "Entire";
    return EraseMode3;
  })(EraseMode || {});
  var TerminalEvent = /* @__PURE__ */ ((TerminalEvent2) => {
    TerminalEvent2["Data"] = "data";
    TerminalEvent2["Binary"] = "binary";
    TerminalEvent2["Resize"] = "resize";
    TerminalEvent2["Title"] = "title";
    TerminalEvent2["Bell"] = "bell";
    TerminalEvent2["Focus"] = "focus";
    TerminalEvent2["Blur"] = "blur";
    TerminalEvent2["Selection"] = "selection";
    TerminalEvent2["Scroll"] = "scroll";
    TerminalEvent2["LineFeed"] = "linefeed";
    return TerminalEvent2;
  })(TerminalEvent || {});

  // src/Buffer.ts
  var DEFAULT_STYLE = {
    bold: false,
    dim: false,
    italic: false,
    underline: false,
    blink: false,
    inverse: false,
    hidden: false,
    strikethrough: false,
    doubleWidth: false
  };
  var DEFAULT_FG = 7;
  var DEFAULT_BG = 0;
  function createBlankCell() {
    return {
      char: " ",
      fg: DEFAULT_FG,
      bg: DEFAULT_BG,
      style: { ...DEFAULT_STYLE },
      width: 1
    };
  }
  var Buffer2 = class {
    constructor(cols, rows, scrollback = 1e3) {
      /** Current scroll offset (0 = bottom, positive = scrolled up) */
      this._scrollOffset = 0;
      /** Scroll region (null = full screen) */
      this._scrollRegion = null;
      /** Saved cursor position for DECSC/DECRC */
      this._savedCursorX = 0;
      this._savedCursorY = 0;
      this.cols = cols;
      this.rows = rows;
      this.scrollbackLimit = scrollback;
      this._lines = [];
      this._scrollback = [];
      this._initLines();
    }
    _initLines() {
      this._lines = [];
      for (let y = 0; y < this.rows; y++) {
        this._lines.push(this._createBlankLine());
      }
    }
    _createBlankLine() {
      const line = [];
      for (let x = 0; x < this.cols; x++) {
        line.push(createBlankCell());
      }
      return line;
    }
    /** Get the scroll offset */
    get scrollOffset() {
      return this._scrollOffset;
    }
    /** Get scrollback line count */
    get scrollbackLength() {
      return this._scrollback.length;
    }
    /** Get the scroll region */
    get scrollRegion() {
      return this._scrollRegion || { top: 0, bottom: this.rows - 1 };
    }
    /** Set the scroll region */
    set scrollRegion(region) {
      this._scrollRegion = region;
    }
    /** Save cursor position */
    saveCursor(x, y) {
      this._savedCursorX = x;
      this._savedCursorY = y;
    }
    /** Restore cursor position */
    restoreCursor() {
      return { x: this._savedCursorX, y: this._savedCursorY };
    }
    /** Get a cell at position considering scroll offset */
    getCell(x, y) {
      const effectiveY = y - this._scrollOffset;
      if (effectiveY < 0) {
        const scrollbackIndex = this._scrollback.length - this._scrollOffset + y;
        if (scrollbackIndex >= 0 && scrollbackIndex < this._scrollback.length && x >= 0 && x < this.cols) {
          return this._scrollback[scrollbackIndex][x];
        }
        return createBlankCell();
      }
      if (y < 0 || y >= this.rows || x < 0 || x >= this.cols) {
        return createBlankCell();
      }
      return this._lines[effectiveY][x];
    }
    /** Get a complete line considering scroll offset */
    getLine(y) {
      const effectiveY = y - this._scrollOffset;
      if (effectiveY < 0) {
        const scrollbackIndex = this._scrollback.length - this._scrollOffset + y;
        if (scrollbackIndex >= 0 && scrollbackIndex < this._scrollback.length) {
          return this._scrollback[scrollbackIndex];
        }
        return this._createBlankLine();
      }
      if (effectiveY >= this.rows) {
        return this._createBlankLine();
      }
      return this._lines[effectiveY];
    }
    /** Set a cell at position */
    setCell(x, y, cell) {
      if (y < 0 || y >= this.rows || x < 0 || x >= this.cols) {
        return;
      }
      const existing = this._lines[y][x];
      this._lines[y][x] = { ...existing, ...cell };
      if (cell.style) {
        this._lines[y][x].style = { ...existing.style, ...cell.style };
      }
    }
    /** Clear the entire buffer */
    clear() {
      this._initLines();
      this._scrollback = [];
      this._scrollOffset = 0;
    }
    /** Scroll up by n lines within the scroll region */
    scrollUp(n = 1) {
      if (n <= 0) return;
      const region = this.scrollRegion;
      for (let i = 0; i < n; i++) {
        const topLine = this._lines[region.top];
        if (this.scrollbackLimit > 0) {
          this._scrollback.push(topLine);
          while (this._scrollback.length > this.scrollbackLimit) {
            this._scrollback.shift();
          }
        }
        for (let y = region.top; y < region.bottom; y++) {
          this._lines[y] = this._lines[y + 1];
        }
        this._lines[region.bottom] = this._createBlankLine();
      }
    }
    /** Scroll down by n lines within the scroll region */
    scrollDown(n = 1) {
      if (n <= 0) return;
      const region = this.scrollRegion;
      for (let i = 0; i < n; i++) {
        for (let y = region.bottom; y > region.top; y--) {
          this._lines[y] = this._lines[y - 1];
        }
        this._lines[region.top] = this._createBlankLine();
      }
    }
    /** Erase in line */
    eraseInLine(y, mode) {
      if (y < 0 || y >= this.rows) return;
      switch (mode) {
        case 0 /* ToEnd */:
          for (let x = 0; x < this.cols; x++) {
            this._lines[y][x] = createBlankCell();
          }
          break;
        case 1 /* ToStart */:
          for (let x = 0; x < this.cols; x++) {
            this._lines[y][x] = createBlankCell();
          }
          break;
        case 2 /* Entire */:
          this._lines[y] = this._createBlankLine();
          break;
      }
    }
    /** Erase in display from cursor position */
    eraseInDisplay(cursorX, cursorY, mode) {
      switch (mode) {
        case 0 /* ToEnd */:
          for (let x = cursorX; x < this.cols; x++) {
            this._lines[cursorY][x] = createBlankCell();
          }
          for (let y = cursorY + 1; y < this.rows; y++) {
            this._lines[y] = this._createBlankLine();
          }
          break;
        case 1 /* ToStart */:
          for (let x = 0; x <= cursorX; x++) {
            this._lines[cursorY][x] = createBlankCell();
          }
          for (let y = 0; y < cursorY; y++) {
            this._lines[y] = this._createBlankLine();
          }
          break;
        case 2 /* Entire */:
          for (let y = 0; y < this.rows; y++) {
            this._lines[y] = this._createBlankLine();
          }
          break;
      }
    }
    /** Insert blank lines at the current position */
    insertLines(y, n) {
      const region = this.scrollRegion;
      if (y < region.top || y > region.bottom) return;
      for (let i = 0; i < n && region.bottom - i >= y; i++) {
        for (let row = region.bottom; row > y; row--) {
          this._lines[row] = this._lines[row - 1];
        }
        this._lines[y] = this._createBlankLine();
      }
    }
    /** Delete lines at the current position */
    deleteLines(y, n) {
      const region = this.scrollRegion;
      if (y < region.top || y > region.bottom) return;
      for (let i = 0; i < n; i++) {
        for (let row = y; row < region.bottom; row++) {
          this._lines[row] = this._lines[row + 1];
        }
        this._lines[region.bottom] = this._createBlankLine();
      }
    }
    /** Insert blank characters at position, shifting existing chars right */
    insertChars(y, x, n) {
      if (y < 0 || y >= this.rows) return;
      const line = this._lines[y];
      for (let col = this.cols - 1; col >= x + n; col--) {
        line[col] = line[col - n];
      }
      for (let col = x; col < Math.min(x + n, this.cols); col++) {
        line[col] = createBlankCell();
      }
    }
    /** Delete characters at position, shifting remaining chars left */
    deleteChars(y, x, n) {
      if (y < 0 || y >= this.rows) return;
      const line = this._lines[y];
      for (let col = x; col < this.cols - n; col++) {
        line[col] = line[col + n];
      }
      for (let col = this.cols - n; col < this.cols; col++) {
        line[col] = createBlankCell();
      }
    }
    /** Scroll the viewport (positive = scroll up / view scrollback) */
    scrollTo(offset) {
      const maxOffset = this._scrollback.length;
      this._scrollOffset = Math.max(0, Math.min(offset, maxOffset));
      if (this._scrollOffset > 0) {
      }
    }
    /** Get a scrollback line */
    getScrollbackLine(index) {
      if (index < 0 || index >= this._scrollback.length) return null;
      return this._scrollback[index];
    }
    /** Get the visible lines considering scroll offset */
    getVisibleLines() {
      return this._lines;
    }
    /** Resize the buffer */
    resize(cols, rows) {
      if (cols === this.cols && rows === this.rows) return;
      if (cols !== this.cols) {
        for (let y = 0; y < this.rows; y++) {
          if (cols < this.cols) {
            this._lines[y] = this._lines[y].slice(0, cols);
          } else {
            const line = this._lines[y];
            for (let x = this.cols; x < cols; x++) {
              line.push(createBlankCell());
            }
          }
        }
      }
      if (rows < this.rows) {
        const excess = this.rows - rows;
        for (let i = 0; i < excess; i++) {
          this._scrollback.push(this._lines[i]);
          while (this._scrollback.length > this.scrollbackLimit) {
            this._scrollback.shift();
          }
        }
        this._lines = this._lines.slice(excess);
      } else if (rows > this.rows) {
        for (let y = this.rows; y < rows; y++) {
          this._lines.push(this._createBlankLine());
        }
      }
      this.cols = cols;
      this.rows = rows;
      this._scrollOffset = 0;
      this._scrollRegion = null;
    }
    /** Get the line count */
    get lineCount() {
      return this._lines.length;
    }
    /** Fill a line with blank cells from startX to end */
    fillLineBlank(y, startX, endX) {
      if (y < 0 || y >= this.rows) return;
      for (let x = startX; x <= endX && x < this.cols; x++) {
        this._lines[y][x] = createBlankCell();
      }
    }
    /** Get all lines as strings (for debugging/testing) */
    toString() {
      return this._lines.map(
        (line) => line.map((cell) => cell.char).join("")
      ).join("\n");
    }
  };

  // src/AnsiParser.ts
  var AnsiParser = class {
    constructor(callbacks) {
      this._state = 0 /* NORMAL */;
      // CSI accumulator
      this._csiParams = [];
      this._csiParamStr = "";
      this._csiIntermediates = "";
      this._csiPrefix = "";
      // OSC accumulator
      this._oscStr = "";
      // ESC accumulator
      this._escIntermediate = "";
      // DCS accumulator
      this._dcsParams = [];
      this._dcsIntermediates = "";
      this._dcsData = "";
      this._callbacks = callbacks;
    }
    /** Parse a string of data */
    parse(data) {
      for (let i = 0; i < data.length; i++) {
        this._parseChar(data.charCodeAt(i), data[i]);
      }
    }
    /** Parse a single character code */
    _parseChar(code, char) {
      switch (this._state) {
        case 0 /* NORMAL */:
          this._parseNormal(code, char);
          break;
        case 1 /* ESC */:
          this._parseEsc(code);
          break;
        case 2 /* CSI_PARAM */:
          this._parseCSIParam(code);
          break;
        case 3 /* CSI_INTERMEDIATE */:
          this._parseCSIIntermediate(code);
          break;
        case 4 /* OSC */:
          this._parseOSC(code, char);
          break;
        case 5 /* OSC_ESC */:
          this._parseOSCEsc(code);
          break;
        case 6 /* ESC_INTERMEDIATE */:
          this._parseEscIntermediate(code);
          break;
        case 7 /* DCS */:
        case 8 /* DCS_PARAM */:
        case 9 /* DCS_INTERMEDIATE */:
        case 10 /* DCS_PASSTHROUGH */:
          this._parseDCS(code, char);
          break;
        case 11 /* SOS */:
        case 12 /* PM */:
        case 13 /* APC */:
          this._parseStringTerminator(code);
          break;
      }
    }
    /** Parse in NORMAL state */
    _parseNormal(code, char) {
      if (code === 27) {
        this._state = 1 /* ESC */;
        return;
      }
      if (code < 32) {
        this._callbacks.execute?.(code);
        return;
      }
      if (code === 127) {
        return;
      }
      this._callbacks.print?.(char, code);
    }
    /** Parse in ESC state */
    _parseEsc(code) {
      if (code < 32) {
        this._callbacks.execute?.(code);
        return;
      }
      if (code === 127) return;
      if (code === 91) {
        this._csiParams = [];
        this._csiParamStr = "";
        this._csiIntermediates = "";
        this._csiPrefix = "";
        this._state = 2 /* CSI_PARAM */;
        return;
      }
      if (code === 93) {
        this._oscStr = "";
        this._state = 4 /* OSC */;
        return;
      }
      if (code === 80) {
        this._dcsParams = [];
        this._dcsIntermediates = "";
        this._dcsData = "";
        this._state = 7 /* DCS */;
        return;
      }
      if (code === 88) {
        this._state = 11 /* SOS */;
        return;
      }
      if (code === 94) {
        this._state = 12 /* PM */;
        return;
      }
      if (code === 95) {
        this._state = 13 /* APC */;
        return;
      }
      if (code >= 32 && code <= 47) {
        this._escIntermediate = String.fromCharCode(code);
        this._state = 6 /* ESC_INTERMEDIATE */;
        return;
      }
      if (code >= 48 && code <= 126) {
        this._callbacks.ESC?.({
          intermediate: "",
          final: String.fromCharCode(code)
        });
        this._state = 0 /* NORMAL */;
        return;
      }
      this._state = 0 /* NORMAL */;
    }
    /** Parse in CSI_PARAM state */
    _parseCSIParam(code) {
      if (code < 32) {
        this._callbacks.execute?.(code);
        return;
      }
      if (code === 127) return;
      if (code >= 48 && code <= 63) {
        if (code === 63) {
          this._csiPrefix = "?";
          return;
        }
        if (code === 62) {
          this._csiPrefix = ">";
          return;
        }
        this._csiParamStr += String.fromCharCode(code);
        return;
      }
      if (code >= 32 && code <= 47) {
        this._csiIntermediates += String.fromCharCode(code);
        this._state = 3 /* CSI_INTERMEDIATE */;
        return;
      }
      if (code >= 64 && code <= 126) {
        this._csiParams = this._parseParams(this._csiParamStr);
        this._callbacks.CSI?.({
          prefix: this._csiPrefix,
          params: this._csiParams,
          intermediates: this._csiIntermediates,
          final: String.fromCharCode(code)
        });
        this._state = 0 /* NORMAL */;
        return;
      }
    }
    /** Parse in CSI_INTERMEDIATE state */
    _parseCSIIntermediate(code) {
      if (code < 32) {
        this._callbacks.execute?.(code);
        return;
      }
      if (code === 127) return;
      if (code >= 32 && code <= 47) {
        this._csiIntermediates += String.fromCharCode(code);
        return;
      }
      if (code >= 64 && code <= 126) {
        this._csiParams = this._parseParams(this._csiParamStr);
        this._callbacks.CSI?.({
          prefix: this._csiPrefix,
          params: this._csiParams,
          intermediates: this._csiIntermediates,
          final: String.fromCharCode(code)
        });
        this._state = 0 /* NORMAL */;
        return;
      }
    }
    /** Parse in OSC state */
    _parseOSC(code, char) {
      if (code === 7) {
        this._callbacks.OSC?.({ command: this._oscStr });
        this._state = 0 /* NORMAL */;
        return;
      }
      if (code === 27) {
        this._state = 5 /* OSC_ESC */;
        return;
      }
      if (code < 32) return;
      if (code === 127) return;
      this._oscStr += char;
    }
    /** Parse in OSC_ESC state (looking for ST = ESC \) */
    _parseOSCEsc(code) {
      if (code === 92) {
        this._callbacks.OSC?.({ command: this._oscStr });
        this._state = 0 /* NORMAL */;
        return;
      }
      this._state = 0 /* NORMAL */;
      this._parseEsc(code);
    }
    /** Parse in ESC_INTERMEDIATE state */
    _parseEscIntermediate(code) {
      if (code < 32) {
        this._callbacks.execute?.(code);
        return;
      }
      if (code === 127) return;
      if (code >= 32 && code <= 47) {
        this._escIntermediate += String.fromCharCode(code);
        return;
      }
      if (code >= 48 && code <= 126) {
        this._callbacks.ESC?.({
          intermediate: this._escIntermediate,
          final: String.fromCharCode(code)
        });
        this._state = 0 /* NORMAL */;
        return;
      }
      this._state = 0 /* NORMAL */;
    }
    /** Parse DCS sequences (simplified - just consume) */
    _parseDCS(code, char) {
      if (code < 32) {
        if (code === 27) {
          this._state = 1 /* ESC */;
        }
        return;
      }
      if (code === 127) return;
      if (code === 27) {
        this._state = 1 /* ESC */;
      }
    }
    /** Parse string terminator sequences (SOS, PM, APC) */
    _parseStringTerminator(code) {
      if (code === 7) {
        this._state = 0 /* NORMAL */;
        return;
      }
      if (code === 27) {
        this._state = 1 /* ESC */;
        return;
      }
    }
    /** Parse CSI parameter string into array of numbers */
    _parseParams(paramStr) {
      if (paramStr === "") return [];
      const parts = paramStr.split(";");
      const params = [];
      for (const part of parts) {
        if (part === "") {
          params.push(0);
        } else {
          const num = parseInt(part, 10);
          params.push(isNaN(num) ? 0 : num);
        }
      }
      return params;
    }
    /** Reset parser state */
    reset() {
      this._state = 0 /* NORMAL */;
      this._csiParams = [];
      this._csiParamStr = "";
      this._csiIntermediates = "";
      this._csiPrefix = "";
      this._oscStr = "";
      this._escIntermediate = "";
    }
  };

  // src/Renderer.ts
  var Renderer = class {
    constructor(canvas, buffer, theme, fontFamily, fontSize, lineHeight, letterSpacing) {
      this._charMetrics = { width: 0, height: 0, baseline: 0 };
      this._selection = null;
      this._cursorBlinkState = true;
      this._cursorBlinkTimer = null;
      this._animationFrame = null;
      this._dirty = true;
      this._scrollOffset = 0;
      this._canvas = canvas;
      this._ctx = canvas.getContext("2d", { alpha: false });
      this._buffer = buffer;
      this._theme = theme;
      this._fontFamily = fontFamily;
      this._fontSize = fontSize;
      this._lineHeight = lineHeight;
      this._letterSpacing = letterSpacing;
      this._devicePixelRatio = window.devicePixelRatio || 1;
      this._cursor = {
        x: 0,
        y: 0,
        visible: true,
        style: "block",
        blink: true
      };
      this._measureChar();
      this._startCursorBlink();
    }
    /** Measure character dimensions based on current font */
    _measureChar() {
      const ctx = this._ctx;
      ctx.font = this._getFontString();
      const metrics = ctx.measureText("M");
      this._charMetrics.width = Math.ceil(metrics.width) + this._letterSpacing;
      this._charMetrics.height = Math.ceil(this._fontSize * this._lineHeight);
      this._charMetrics.baseline = Math.ceil(
        metrics.actualBoundingBoxAscent || this._fontSize
      );
    }
    /** Get the CSS font string */
    _getFontString(bold = false, italic = false) {
      const parts = [];
      if (italic) parts.push("italic");
      if (bold) parts.push("bold");
      parts.push(`${this._fontSize}px`);
      parts.push(this._fontFamily);
      return parts.join(" ");
    }
    /** Get character metrics */
    get charMetrics() {
      return { ...this._charMetrics };
    }
    /** Get the pixel dimensions of the terminal */
    get dimensions() {
      return {
        width: this._buffer.cols * this._charMetrics.width,
        height: this._buffer.rows * this._charMetrics.height,
        cellWidth: this._charMetrics.width,
        cellHeight: this._charMetrics.height
      };
    }
    /** Update cursor state */
    setCursor(cursor) {
      this._cursor = { ...cursor };
      this._dirty = true;
      this._resetCursorBlink();
    }
    /** Update selection */
    setSelection(selection) {
      this._selection = selection;
      this._dirty = true;
    }
    /** Set scroll offset for scrollback viewing */
    setScrollOffset(offset) {
      this._scrollOffset = offset;
      this._dirty = true;
    }
    /** Mark the renderer as needing a redraw */
    markDirty() {
      this._dirty = true;
    }
    /** Resize the canvas to match the buffer dimensions */
    resize(cols, rows) {
      this._devicePixelRatio = window.devicePixelRatio || 1;
      const width = cols * this._charMetrics.width;
      const height = rows * this._charMetrics.height;
      this._canvas.width = width * this._devicePixelRatio;
      this._canvas.height = height * this._devicePixelRatio;
      this._canvas.style.width = `${width}px`;
      this._canvas.style.height = `${height}px`;
      this._ctx.setTransform(this._devicePixelRatio, 0, 0, this._devicePixelRatio, 0, 0);
      this._dirty = true;
    }
    /** Full render of the terminal */
    render() {
      const ctx = this._ctx;
      const { width, height, cellWidth, cellHeight } = this.dimensions;
      ctx.fillStyle = this._theme.background;
      ctx.fillRect(0, 0, width, height);
      this._renderBuffer(ctx, cellWidth, cellHeight);
      if (this._selection && this._selection.start && this._selection.end) {
        this._renderSelection(ctx, cellWidth, cellHeight);
      }
      if (this._cursor.visible) {
        this._renderCursor(ctx, cellWidth, cellHeight);
      }
      this._dirty = false;
    }
    /** Schedule a render on the next animation frame */
    scheduleRender() {
      if (this._animationFrame !== null) return;
      this._animationFrame = requestAnimationFrame(() => {
        this._animationFrame = null;
        if (this._dirty) {
          this.render();
        }
      });
    }
    /** Render the buffer content */
    _renderBuffer(ctx, cellWidth, cellHeight) {
      const buffer = this._buffer;
      const scrollOffset = this._scrollOffset;
      for (let row = 0; row < buffer.rows; row++) {
        const bufferRow = row;
        const line = buffer.getLine(bufferRow);
        const y = row * cellHeight;
        let col = 0;
        while (col < buffer.cols) {
          const cell = line[col];
          const x = col * cellWidth;
          const bgColor = this._resolveColor(cell.bg, true);
          ctx.fillStyle = bgColor;
          ctx.fillRect(x, y, cellWidth * cell.width, cellHeight);
          if (cell.char && cell.char !== " ") {
            const fgColor = cell.style.inverse ? this._resolveColor(cell.bg, true) : this._resolveColor(cell.fg, false, cell.style.bold, cell.style.dim);
            ctx.font = this._getFontString(cell.style.bold, cell.style.italic);
            ctx.fillStyle = fgColor;
            ctx.textBaseline = "middle";
            const textY = y + cellHeight / 2;
            if (cell.style.underline) {
              ctx.save();
              ctx.fillText(cell.char, x + this._letterSpacing / 2, textY);
              ctx.strokeStyle = fgColor;
              ctx.lineWidth = 1;
              ctx.beginPath();
              ctx.moveTo(x, y + cellHeight - 1);
              ctx.lineTo(x + cellWidth * cell.width, y + cellHeight - 1);
              ctx.stroke();
              ctx.restore();
            } else {
              ctx.fillText(cell.char, x + this._letterSpacing / 2, textY);
            }
            if (cell.style.strikethrough) {
              ctx.strokeStyle = fgColor;
              ctx.lineWidth = 1;
              ctx.beginPath();
              ctx.moveTo(x, y + cellHeight / 2);
              ctx.lineTo(x + cellWidth * cell.width, y + cellHeight / 2);
              ctx.stroke();
            }
          }
          col += cell.width;
        }
      }
    }
    /** Render selection highlight */
    _renderSelection(ctx, cellWidth, cellHeight) {
      if (!this._selection || !this._selection.start || !this._selection.end) return;
      const { start, end } = this._normalizeSelection();
      if (!start || !end) return;
      ctx.fillStyle = this._theme.selectionBackground + "88";
      if (start.y === end.y) {
        ctx.fillRect(
          start.x * cellWidth,
          start.y * cellHeight,
          (end.x - start.x + 1) * cellWidth,
          cellHeight
        );
      } else {
        ctx.fillRect(
          start.x * cellWidth,
          start.y * cellHeight,
          (this._buffer.cols - start.x) * cellWidth,
          cellHeight
        );
        for (let row = start.y + 1; row < end.y; row++) {
          ctx.fillRect(0, row * cellHeight, this._buffer.cols * cellWidth, cellHeight);
        }
        ctx.fillRect(
          0,
          end.y * cellHeight,
          (end.x + 1) * cellWidth,
          cellHeight
        );
      }
    }
    /** Normalize selection so start <= end */
    _normalizeSelection() {
      if (!this._selection?.start || !this._selection?.end) {
        return { start: null, end: null };
      }
      const start = this._selection.start;
      const end = this._selection.end;
      const clamp = (val, max) => Math.max(0, Math.min(val, max - 1));
      const clampedStart = {
        x: clamp(start.x, this._buffer.cols),
        y: clamp(start.y, this._buffer.rows)
      };
      const clampedEnd = {
        x: clamp(end.x, this._buffer.cols),
        y: clamp(end.y, this._buffer.rows)
      };
      if (clampedStart.y < clampedEnd.y || clampedStart.y === clampedEnd.y && clampedStart.x <= clampedEnd.x) {
        return { start: clampedStart, end: clampedEnd };
      }
      return { start: clampedEnd, end: clampedStart };
    }
    /** Render the cursor */
    _renderCursor(ctx, cellWidth, cellHeight) {
      if (!this._cursorBlinkState && this._cursor.blink) return;
      const x = this._cursor.x * cellWidth;
      const y = this._cursor.y * cellHeight;
      ctx.save();
      switch (this._cursor.style) {
        case "block":
          ctx.fillStyle = this._theme.cursor;
          ctx.fillRect(x, y, cellWidth, cellHeight);
          const cell = this._buffer.getCell(this._cursor.x, this._cursor.y);
          if (cell.char && cell.char !== " ") {
            ctx.font = this._getFontString(cell.style.bold, cell.style.italic);
            ctx.fillStyle = this._theme.cursorAccent;
            ctx.textBaseline = "middle";
            ctx.fillText(cell.char, x + this._letterSpacing / 2, y + cellHeight / 2);
          }
          break;
        case "underline":
          ctx.fillStyle = this._theme.cursor;
          ctx.fillRect(x, y + cellHeight - 2, cellWidth, 2);
          break;
        case "bar":
          ctx.fillStyle = this._theme.cursor;
          ctx.fillRect(x, y, 2, cellHeight);
          break;
      }
      ctx.restore();
    }
    /** Resolve a TerminalColor to a CSS color string */
    _resolveColor(color, isBackground, bold = false, dim = false) {
      if (typeof color === "string") {
        return color;
      }
      if (Array.isArray(color)) {
        return `rgb(${color[0]},${color[1]},${color[2]})`;
      }
      const index = color;
      if (index === -1) {
        return isBackground ? this._theme.background : this._theme.foreground;
      }
      const themeColors = [
        this._theme.black,
        this._theme.red,
        this._theme.green,
        this._theme.yellow,
        this._theme.blue,
        this._theme.magenta,
        this._theme.cyan,
        this._theme.white,
        this._theme.brightBlack,
        this._theme.brightRed,
        this._theme.brightGreen,
        this._theme.brightYellow,
        this._theme.brightBlue,
        this._theme.brightMagenta,
        this._theme.brightCyan,
        this._theme.brightWhite
      ];
      if (index >= 0 && index < 8) {
        if (bold && !isBackground) {
          return themeColors[index + 8];
        }
        return themeColors[index];
      }
      if (index >= 8 && index < 16) {
        return themeColors[index];
      }
      if (index >= 16 && index <= 231) {
        const cubeIndex = index - 16;
        const r = Math.floor(cubeIndex / 36);
        const g = Math.floor(cubeIndex % 36 / 6);
        const b = cubeIndex % 6;
        const cubeValues = [0, 95, 135, 175, 215, 255];
        return `rgb(${cubeValues[r]},${cubeValues[g]},${cubeValues[b]})`;
      }
      if (index >= 232 && index <= 255) {
        const gray = 8 + (index - 232) * 10;
        return `rgb(${gray},${gray},${gray})`;
      }
      return isBackground ? this._theme.background : this._theme.foreground;
    }
    /** Start cursor blink animation */
    _startCursorBlink() {
      if (!this._cursor.blink) return;
      this._cursorBlinkState = true;
      this._cursorBlinkTimer = window.setInterval(() => {
        this._cursorBlinkState = !this._cursorBlinkState;
        this._dirty = true;
        this.scheduleRender();
      }, 600);
    }
    /** Reset cursor blink (on keypress, etc.) */
    _resetCursorBlink() {
      this._cursorBlinkState = true;
      if (this._cursorBlinkTimer !== null) {
        clearInterval(this._cursorBlinkTimer);
      }
      this._startCursorBlink();
    }
    /** Update theme */
    setTheme(theme) {
      this._theme = theme;
      this._dirty = true;
      this.scheduleRender();
    }
    /** Update font settings */
    setFont(fontFamily, fontSize, lineHeight, letterSpacing) {
      this._fontFamily = fontFamily;
      this._fontSize = fontSize;
      this._lineHeight = lineHeight;
      this._letterSpacing = letterSpacing;
      this._measureChar();
      this._dirty = true;
      this.scheduleRender();
    }
    /** Dispose of the renderer */
    dispose() {
      if (this._cursorBlinkTimer !== null) {
        clearInterval(this._cursorBlinkTimer);
      }
      if (this._animationFrame !== null) {
        cancelAnimationFrame(this._animationFrame);
      }
    }
    /** Convert pixel coordinates to buffer cell coordinates */
    pixelToCell(px, py) {
      return {
        col: Math.floor(px / this._charMetrics.width),
        row: Math.floor(py / this._charMetrics.height)
      };
    }
  };

  // src/InputHandler.ts
  var InputHandler = class {
    constructor(container, buffer, renderer, wordSeparators = ` ()[]{}'"`, enableMouseScroll = true) {
      this._listeners = /* @__PURE__ */ new Map();
      this._selection = {
        start: null,
        end: null,
        active: false
      };
      this._isFocused = false;
      this._mouseDown = false;
      // ---- Event handlers ----
      this._onClick = () => {
        this._textarea.focus();
      };
      this._onFocus = () => {
        this._isFocused = true;
        this._emit("focus" /* Focus */);
      };
      this._onBlur = () => {
        this._isFocused = false;
        this._emit("blur" /* Blur */);
      };
      this._onKeyDown = (e) => {
        const sequences = this._mapKeyToSequence(e);
        if (sequences !== null) {
          e.preventDefault();
          this._emit("data" /* Data */, sequences);
          return;
        }
        if (e.ctrlKey && !e.altKey && !e.metaKey) {
          const ctrlSeq = this._mapCtrlKey(e);
          if (ctrlSeq !== null) {
            e.preventDefault();
            this._emit("data" /* Data */, ctrlSeq);
            return;
          }
        }
        if (e.altKey && e.key.length === 1) {
          e.preventDefault();
          this._emit("data" /* Data */, `\x1B${e.key}`);
          return;
        }
      };
      this._onInput = (e) => {
        const data = this._textarea.value;
        this._textarea.value = "";
        if (data) {
          this._emit("data" /* Data */, data);
        }
      };
      this._onCompositionEnd = (e) => {
        if (e.data) {
          this._emit("data" /* Data */, e.data);
        }
        this._textarea.value = "";
      };
      this._onMouseDown = (e) => {
        if (e.button !== 0) return;
        this._mouseDown = true;
        const { col, row } = this._renderer.pixelToCell(
          e.offsetX,
          e.offsetY
        );
        this._selection = {
          start: { x: col, y: row },
          end: { x: col, y: row },
          active: true
        };
        this._renderer.setSelection(this._selection);
        this._textarea.focus();
      };
      this._onMouseMove = (e) => {
        if (!this._mouseDown) return;
        const { col, row } = this._renderer.pixelToCell(
          e.offsetX,
          e.offsetY
        );
        this._selection.end = { x: col, y: row };
        this._renderer.setSelection(this._selection);
      };
      this._onMouseUp = (e) => {
        if (e.button !== 0) return;
        this._mouseDown = false;
        if (this._selection.start && this._selection.end) {
          const isSelection = this._selection.start.x !== this._selection.end.x || this._selection.start.y !== this._selection.end.y;
          if (isSelection) {
            this._emit("selection" /* Selection */);
            this._copySelection();
          } else {
            this._selection.active = false;
            this._renderer.setSelection(null);
          }
        }
      };
      this._onDoubleClick = (e) => {
        const { col, row } = this._renderer.pixelToCell(
          e.offsetX,
          e.offsetY
        );
        const wordBounds = this._findWordBounds(col, row);
        if (wordBounds) {
          this._selection = {
            start: { x: wordBounds.startCol, y: row },
            end: { x: wordBounds.endCol, y: row },
            active: true
          };
          this._renderer.setSelection(this._selection);
          this._emit("selection" /* Selection */);
          this._copySelection();
        }
      };
      this._onWheel = (e) => {
        e.preventDefault();
        const delta = Math.sign(e.deltaY);
        const currentOffset = this._buffer.scrollOffset;
        const newOffset = currentOffset + delta;
        if (newOffset !== currentOffset) {
          this._buffer.scrollTo(newOffset);
          this._renderer.setScrollOffset(this._buffer.scrollOffset);
          this._renderer.markDirty();
          this._renderer.scheduleRender();
          this._emit("scroll" /* Scroll */, this._buffer.scrollOffset);
        }
      };
      this._onContextMenu = (e) => {
        e.preventDefault();
      };
      // ---- Event system ----
      this._eventHandlers = /* @__PURE__ */ new Map();
      this._container = container;
      this._buffer = buffer;
      this._renderer = renderer;
      this._wordSeparators = wordSeparators;
      this._enableMouseScroll = enableMouseScroll;
      this._textarea = document.createElement("textarea");
      this._textarea.style.position = "absolute";
      this._textarea.style.left = "-9999px";
      this._textarea.style.top = "0";
      this._textarea.style.width = "1px";
      this._textarea.style.height = "1px";
      this._textarea.style.opacity = "0";
      this._textarea.setAttribute("autocapitalize", "off");
      this._textarea.setAttribute("autocorrect", "off");
      this._textarea.setAttribute("autocomplete", "off");
      this._textarea.setAttribute("spellcheck", "false");
      this._textarea.setAttribute("aria-label", "Terminal input");
      container.appendChild(this._textarea);
      this._attachListeners();
    }
    _attachListeners() {
      this._container.addEventListener("click", this._onClick);
      this._textarea.addEventListener("keydown", this._onKeyDown);
      this._textarea.addEventListener("input", this._onInput);
      this._textarea.addEventListener("compositionend", this._onCompositionEnd);
      this._textarea.addEventListener("focus", this._onFocus);
      this._textarea.addEventListener("blur", this._onBlur);
      this._container.addEventListener("mousedown", this._onMouseDown);
      this._container.addEventListener("mousemove", this._onMouseMove);
      this._container.addEventListener("mouseup", this._onMouseUp);
      this._container.addEventListener("dblclick", this._onDoubleClick);
      if (this._enableMouseScroll) {
        this._container.addEventListener("wheel", this._onWheel, { passive: false });
      }
      this._container.addEventListener("contextmenu", this._onContextMenu);
    }
    /** Focus the terminal */
    focus() {
      this._textarea.focus();
    }
    /** Blur the terminal */
    blur() {
      this._textarea.blur();
    }
    /** Check if terminal is focused */
    get isFocused() {
      return this._isFocused;
    }
    // ---- Key mapping ----
    /** Map keyboard events to ANSI escape sequences */
    _mapKeyToSequence(e) {
      const key = e.key;
      const shift = e.shiftKey;
      const ctrl = e.ctrlKey;
      const alt = e.altKey;
      const appCursor = false;
      const prefix = appCursor ? "\x1BO" : "\x1B[";
      switch (key) {
        case "Enter":
          return "\r";
        case "Backspace":
          return "\x7F";
        case "Delete":
          return prefix + "3~";
        case "Tab":
          return "	";
        case "Escape":
          return "\x1B";
        case "Home":
          return shift ? prefix + "1~" : prefix + "H";
        case "End":
          return shift ? prefix + "4~" : prefix + "F";
        case "Insert":
          return prefix + "2~";
        case "PageUp":
          return shift ? "\x1B[5;2~" : prefix + "5~";
        case "PageDown":
          return shift ? "\x1B[6;2~" : prefix + "6~";
        case "ArrowUp":
          if (shift) return "\x1B[1;2A";
          if (ctrl) return "\x1B[1;5A";
          if (alt) return "\x1B[1;3A";
          return prefix + "A";
        case "ArrowDown":
          if (shift) return "\x1B[1;2B";
          if (ctrl) return "\x1B[1;5B";
          if (alt) return "\x1B[1;3B";
          return prefix + "B";
        case "ArrowRight":
          if (shift) return "\x1B[1;2C";
          if (ctrl) return "\x1B[1;5C";
          if (alt) return "\x1B[1;3C";
          return prefix + "C";
        case "ArrowLeft":
          if (shift) return "\x1B[1;2D";
          if (ctrl) return "\x1B[1;5D";
          if (alt) return "\x1B[1;3D";
          return prefix + "D";
        case "F1":
          return "\x1BOP";
        case "F2":
          return "\x1BOQ";
        case "F3":
          return "\x1BOR";
        case "F4":
          return "\x1BOS";
        case "F5":
          return "\x1B[15~";
        case "F6":
          return "\x1B[17~";
        case "F7":
          return "\x1B[18~";
        case "F8":
          return "\x1B[19~";
        case "F9":
          return "\x1B[20~";
        case "F10":
          return "\x1B[21~";
        case "F11":
          return "\x1B[23~";
        case "F12":
          return "\x1B[24~";
        default:
          return null;
      }
    }
    /** Map Ctrl+key combinations to control characters */
    _mapCtrlKey(e) {
      const key = e.key.toLowerCase();
      const ctrlMap = {
        "a": "",
        "b": "",
        "c": "",
        "d": "",
        "e": "",
        "f": "",
        "g": "\x07",
        "h": "\b",
        "i": "	",
        "j": "\n",
        "k": "\v",
        "l": "\f",
        "m": "\r",
        "n": "",
        "o": "",
        "p": "",
        "q": "",
        "r": "",
        "s": "",
        "t": "",
        "u": "",
        "v": "",
        "w": "",
        "x": "",
        "y": "",
        "z": "",
        "[": "\x1B",
        "\\": "",
        "]": "",
        "2": "\0",
        "6": "",
        "-": ""
      };
      if (key === "c") {
        return ctrlMap[key] || null;
      }
      return ctrlMap[key] || null;
    }
    // ---- Selection helpers ----
    /** Find word boundaries at a position */
    _findWordBounds(col, row) {
      if (row < 0 || row >= this._buffer.rows) return null;
      const line = this._buffer.getLine(row);
      let startCol = col;
      let endCol = col;
      while (startCol > 0) {
        const prevChar = line[startCol - 1].char;
        if (this._wordSeparators.includes(prevChar)) break;
        startCol--;
      }
      while (endCol < this._buffer.cols - 1) {
        const nextChar = line[endCol + 1].char;
        if (this._wordSeparators.includes(nextChar)) break;
        endCol++;
      }
      return { startCol, endCol };
    }
    /** Get the selected text */
    getSelectionText() {
      if (!this._selection.start || !this._selection.end) return null;
      const start = this._selection.start;
      const end = this._selection.end;
      const normalized = start.y < end.y || start.y === end.y && start.x <= end.x ? { start, end } : { start: end, end: start };
      const lines = [];
      for (let row = normalized.start.y; row <= normalized.end.y; row++) {
        const line = this._buffer.getLine(row);
        const startCol = row === normalized.start.y ? normalized.start.x : 0;
        const endCol = row === normalized.end.y ? normalized.end.x : this._buffer.cols - 1;
        let text = "";
        for (let col = startCol; col <= endCol; col++) {
          text += line[col].char;
        }
        lines.push(text.trimEnd());
      }
      return lines.join("\n");
    }
    /** Copy selection to clipboard */
    async _copySelection() {
      const text = this.getSelectionText();
      if (!text) return;
      try {
        await navigator.clipboard.writeText(text);
      } catch {
        this._textarea.value = text;
        this._textarea.select();
        document.execCommand("copy");
        this._textarea.value = "";
      }
    }
    /** Clear the selection */
    clearSelection() {
      this._selection = { start: null, end: null, active: false };
      this._renderer.setSelection(null);
    }
    on(event, callback) {
      if (!this._eventHandlers.has(event)) {
        this._eventHandlers.set(event, /* @__PURE__ */ new Set());
      }
      this._eventHandlers.get(event).add(callback);
    }
    off(event, callback) {
      this._eventHandlers.get(event)?.delete(callback);
    }
    _emit(event, ...args) {
      this._eventHandlers.get(event)?.forEach((cb) => cb(...args));
    }
    /** Dispose of the input handler */
    dispose() {
      this._container.removeEventListener("click", this._onClick);
      this._textarea.removeEventListener("keydown", this._onKeyDown);
      this._textarea.removeEventListener("input", this._onInput);
      this._textarea.removeEventListener("compositionend", this._onCompositionEnd);
      this._textarea.removeEventListener("focus", this._onFocus);
      this._textarea.removeEventListener("blur", this._onBlur);
      this._container.removeEventListener("mousedown", this._onMouseDown);
      this._container.removeEventListener("mousemove", this._onMouseMove);
      this._container.removeEventListener("mouseup", this._onMouseUp);
      this._container.removeEventListener("dblclick", this._onDoubleClick);
      this._container.removeEventListener("wheel", this._onWheel);
      this._container.removeEventListener("contextmenu", this._onContextMenu);
      this._textarea.remove();
      this._eventHandlers.clear();
    }
  };

  // src/Theme.ts
  var DEFAULT_THEME = {
    background: "#000000",
    foreground: "#ffffff",
    cursor: "#ffffff",
    cursorAccent: "#000000",
    selectionBackground: "#264f78",
    selectionForeground: "#ffffff",
    black: "#000000",
    red: "#cd0000",
    green: "#00cd00",
    yellow: "#cdcd00",
    blue: "#0000ee",
    magenta: "#cd00cd",
    cyan: "#00cdcd",
    white: "#e5e5e5",
    brightBlack: "#7f7f7f",
    brightRed: "#ff0000",
    brightGreen: "#00ff00",
    brightYellow: "#ffff00",
    brightBlue: "#5c5cff",
    brightMagenta: "#ff00ff",
    brightCyan: "#00ffff",
    brightWhite: "#ffffff"
  };
  var ONE_DARK_THEME = {
    background: "#282c34",
    foreground: "#abb2bf",
    cursor: "#528bff",
    cursorAccent: "#282c34",
    selectionBackground: "#3e4451",
    selectionForeground: "#abb2bf",
    black: "#282c34",
    red: "#e06c75",
    green: "#98c379",
    yellow: "#e5c07b",
    blue: "#61afef",
    magenta: "#c678dd",
    cyan: "#56b6c2",
    white: "#abb2bf",
    brightBlack: "#5c6370",
    brightRed: "#e06c75",
    brightGreen: "#98c379",
    brightYellow: "#e5c07b",
    brightBlue: "#61afef",
    brightMagenta: "#c678dd",
    brightCyan: "#56b6c2",
    brightWhite: "#ffffff"
  };
  var SOLARIZED_DARK_THEME = {
    background: "#002b36",
    foreground: "#839496",
    cursor: "#93a1a1",
    cursorAccent: "#002b36",
    selectionBackground: "#073642",
    selectionForeground: "#839496",
    black: "#073642",
    red: "#dc322f",
    green: "#859900",
    yellow: "#b58900",
    blue: "#268bd2",
    magenta: "#d33682",
    cyan: "#2aa198",
    white: "#eee8d5",
    brightBlack: "#002b36",
    brightRed: "#cb4b16",
    brightGreen: "#586e75",
    brightYellow: "#657b83",
    brightBlue: "#839496",
    brightMagenta: "#6c71c4",
    brightCyan: "#93a1a1",
    brightWhite: "#fdf6e3"
  };
  var DRACULA_THEME = {
    background: "#1e1f29",
    foreground: "#f8f8f2",
    cursor: "#bbbbbb",
    cursorAccent: "#1e1f29",
    selectionBackground: "#44475a",
    selectionForeground: "#f8f8f2",
    black: "#000000",
    red: "#ff5555",
    green: "#50fa7b",
    yellow: "#f1fa8c",
    blue: "#bd93f9",
    magenta: "#ff79c6",
    cyan: "#8be9fd",
    white: "#bbbbbb",
    brightBlack: "#555555",
    brightRed: "#ff5555",
    brightGreen: "#50fa7b",
    brightYellow: "#f1fa8c",
    brightBlue: "#bd93f9",
    brightMagenta: "#ff79c6",
    brightCyan: "#8be9fd",
    brightWhite: "#ffffff"
  };
  function mergeTheme(partial) {
    return { ...DEFAULT_THEME, ...partial };
  }

  // src/Terminal.ts
  var DEFAULT_OPTIONS = {
    cols: 80,
    rows: 24,
    fontFamily: "Ubuntu Mono, Consolas, Courier New, monospace",
    fontSize: 13,
    lineHeight: 1.2,
    letterSpacing: 0,
    scrollback: 1e3,
    theme: {},
    cursorStyle: "block",
    cursorBlink: true,
    allowTransparency: false,
    focusOnOpen: false,
    screenReaderMode: false,
    rightClickSelectsWord: false,
    wordSeparators: ` ()[]{}'"`,
    drawBoldTextInBrightColors: true,
    showScrollbar: false,
    enableMouseScroll: true
  };
  var AnetsTerminal = class {
    constructor(options) {
      this._renderer = null;
      this._inputHandler = null;
      // DOM
      this._container = null;
      this._canvas = null;
      this._scrollbar = null;
      // Cursor state
      this._cursorX = 0;
      this._cursorY = 0;
      this._cursorVisible = true;
      // Current text attributes
      this._currentFg = -1;
      // default (use theme foreground)
      this._currentBg = -1;
      // default (use theme background)
      this._currentStyle = {
        bold: false,
        dim: false,
        italic: false,
        underline: false,
        blink: false,
        inverse: false,
        hidden: false,
        strikethrough: false,
        doubleWidth: false
      };
      // Terminal modes
      this._insertMode = false;
      this._originMode = false;
      this._autoWrap = true;
      this._cursorKeyMode = false;
      // false = normal, true = application
      this._columnMode = false;
      // Event system
      this._eventHandlers = /* @__PURE__ */ new Map();
      // Title
      this._title = "";
      // Saved cursor state (DECSC/DECRC)
      this._savedCursorX = 0;
      this._savedCursorY = 0;
      this._savedFg = -1;
      this._savedBg = -1;
      this._savedStyle = { ...this._currentStyle };
      this._options = { ...DEFAULT_OPTIONS, ...options };
      this._theme = mergeTheme(this._options.theme);
      this._cursorStyle = this._options.cursorStyle;
      this._cursorBlink = this._options.cursorBlink;
      this._buffer = new Buffer2(this._options.cols, this._options.rows, this._options.scrollback);
      this._tabStops = [];
      for (let i = 0; i < this._options.cols; i++) {
        this._tabStops.push(i % 8 === 0);
      }
      this._parser = new AnsiParser({
        print: (char, code) => this._print(char),
        execute: (code) => this._execute(code),
        CSI: (seq) => this._handleCSI(seq),
        ESC: (seq) => this._handleESC(seq),
        OSC: (seq) => this._handleOSC(seq)
      });
    }
    // =============================================
    // Public API
    // =============================================
    /** Open the terminal in a container element */
    open(container) {
      this._container = container;
      container.style.position = "relative";
      container.style.overflow = "hidden";
      container.style.backgroundColor = this._theme.background;
      this._canvas = document.createElement("canvas");
      this._canvas.style.display = "block";
      this._canvas.style.cursor = "text";
      container.appendChild(this._canvas);
      if (this._options.showScrollbar) {
        this._scrollbar = document.createElement("div");
        this._scrollbar.style.position = "absolute";
        this._scrollbar.style.right = "0";
        this._scrollbar.style.top = "0";
        this._scrollbar.style.width = "12px";
        this._scrollbar.style.height = "100%";
        this._scrollbar.style.backgroundColor = "#333";
        this._scrollbar.style.overflow = "hidden";
        this._scrollbar.style.zIndex = "100";
        const thumb = document.createElement("div");
        thumb.style.position = "absolute";
        thumb.style.width = "100%";
        thumb.style.backgroundColor = "#666";
        thumb.style.borderRadius = "6px";
        thumb.style.cursor = "pointer";
        thumb.style.transition = "background-color 0.2s";
        thumb.dataset.isDragging = "false";
        this._scrollbar.appendChild(thumb);
        container.appendChild(this._scrollbar);
        this._attachScrollbarListeners();
        this._updateScrollbar();
      }
      this._renderer = new Renderer(
        this._canvas,
        this._buffer,
        this._theme,
        this._options.fontFamily,
        this._options.fontSize,
        this._options.lineHeight,
        this._options.letterSpacing
      );
      this._renderer.resize(this._options.cols, this._options.rows);
      this._inputHandler = new InputHandler(
        container,
        this._buffer,
        this._renderer,
        this._options.wordSeparators,
        this._options.enableMouseScroll
      );
      this._inputHandler.on("data" /* Data */, (data) => {
        this._emit("data" /* Data */, data);
      });
      this._inputHandler.on("focus" /* Focus */, () => this._emit("focus" /* Focus */));
      this._inputHandler.on("blur" /* Blur */, () => this._emit("blur" /* Blur */));
      this._inputHandler.on("scroll" /* Scroll */, (offset) => {
        this._updateScrollbar();
        this._emit("scroll" /* Scroll */, offset);
      });
      this._inputHandler.on("selection" /* Selection */, () => this._emit("selection" /* Selection */));
      this._handleResize = this._handleResize.bind(this);
      this._renderer.render();
      if (this._options.focusOnOpen) {
        this._inputHandler.focus();
      }
    }
    /** Write data to the terminal (as if received from the backend) */
    write(data) {
      if (typeof data === "string") {
        this._parser.parse(data);
      } else {
        let str = "";
        for (let i = 0; i < data.length; i++) {
          str += String.fromCharCode(data[i]);
        }
        this._parser.parse(str);
      }
      this._requestRender();
    }
    /** Write data to the terminal and immediately flush */
    writeln(data) {
      this.write(data + "\r\n");
    }
    /** Get the current terminal rows */
    get rows() {
      return this._buffer.rows;
    }
    /** Get the current terminal columns */
    get cols() {
      return this._buffer.cols;
    }
    /** Get the buffer */
    get buffer() {
      return this._buffer;
    }
    /** Get current cursor position */
    get cursorX() {
      return this._cursorX;
    }
    get cursorY() {
      return this._cursorY;
    }
    /** Get the terminal title */
    get title() {
      return this._title;
    }
    /** Get whether the terminal is focused */
    get isFocused() {
      return this._inputHandler?.isFocused ?? false;
    }
    /** Register an event handler */
    on(event, callback) {
      if (!this._eventHandlers.has(event)) {
        this._eventHandlers.set(event, /* @__PURE__ */ new Set());
      }
      this._eventHandlers.get(event).add(callback);
    }
    /** Remove an event handler */
    off(event, callback) {
      this._eventHandlers.get(event)?.delete(callback);
    }
    /** Focus the terminal */
    focus() {
      this._inputHandler?.focus();
    }
    /** Blur the terminal */
    blur() {
      this._inputHandler?.blur();
    }
    /** Resize the terminal */
    resize(cols, rows) {
      if (cols === this._buffer.cols && rows === this._buffer.rows) return;
      this._buffer.resize(cols, rows);
      this._renderer?.resize(cols, rows);
      this._options.cols = cols;
      this._options.rows = rows;
      this._tabStops = [];
      for (let i = 0; i < cols; i++) {
        this._tabStops.push(i % 8 === 0);
      }
      this._cursorX = Math.min(this._cursorX, cols - 1);
      this._cursorY = Math.min(this._cursorY, rows - 1);
      this._emit("resize" /* Resize */, { cols, rows });
      this._requestRender();
    }
    /** Set the terminal theme */
    setTheme(theme) {
      this._theme = mergeTheme(theme);
      this._renderer?.setTheme(this._theme);
      if (this._container) {
        this._container.style.backgroundColor = this._theme.background;
      }
    }
    /** Set the font */
    setFont(fontFamily, fontSize) {
      if (fontFamily) this._options.fontFamily = fontFamily;
      if (fontSize) this._options.fontSize = fontSize;
      this._renderer?.setFont(
        this._options.fontFamily,
        this._options.fontSize,
        this._options.lineHeight,
        this._options.letterSpacing
      );
    }
    /** Clear the terminal */
    clear() {
      this._buffer.clear();
      this._cursorX = 0;
      this._cursorY = 0;
      this._requestRender();
    }
    /** Reset the terminal to initial state */
    reset() {
      this._buffer.clear();
      this._cursorX = 0;
      this._cursorY = 0;
      this._cursorVisible = true;
      this._cursorStyle = this._options.cursorStyle;
      this._insertMode = false;
      this._originMode = false;
      this._autoWrap = true;
      this._currentFg = -1;
      this._currentBg = -1;
      this._currentStyle = {
        bold: false,
        dim: false,
        italic: false,
        underline: false,
        blink: false,
        inverse: false,
        hidden: false,
        strikethrough: false,
        doubleWidth: false
      };
      this._parser.reset();
      this._requestRender();
    }
    /** Get the selected text */
    getSelection() {
      return this._inputHandler?.getSelectionText() ?? null;
    }
    /** Clear the current selection */
    clearSelection() {
      this._inputHandler?.clearSelection();
    }
    /** Scroll to a specific position in scrollback */
    scrollTo(offset) {
      this._buffer.scrollTo(offset);
      this._renderer?.setScrollOffset(this._buffer.scrollOffset);
      this._requestRender();
    }
    /** Scroll to the bottom of the buffer */
    scrollToBottom() {
      this._buffer.scrollTo(0);
      this._renderer?.setScrollOffset(0);
      this._requestRender();
    }
    /** Get the scroll offset */
    get scrollOffset() {
      return this._buffer.scrollOffset;
    }
    /** Update scrollbar position and size */
    _updateScrollbar() {
      if (!this._scrollbar) return;
      const thumb = this._scrollbar.querySelector("div");
      if (!thumb) return;
      const totalLines = this._buffer.scrollbackLength + this._buffer.rows;
      const visibleLines = this._buffer.rows;
      const scrollOffset = this._buffer.scrollOffset;
      const maxScroll = totalLines - visibleLines;
      if (totalLines <= visibleLines) {
        thumb.style.height = "100%";
        thumb.style.top = "0";
      } else {
        const scrollbarHeight = this._scrollbar.clientHeight;
        const thumbHeight = visibleLines / totalLines * scrollbarHeight;
        const thumbTop = (1 - scrollOffset / maxScroll) * (scrollbarHeight - thumbHeight);
        thumb.style.height = `${Math.max(20, thumbHeight)}px`;
        thumb.style.top = `${thumbTop}px`;
      }
    }
    /** Attach scrollbar event listeners */
    _attachScrollbarListeners() {
      if (!this._scrollbar) return;
      const thumb = this._scrollbar.querySelector("div");
      if (!thumb) return;
      let isDragging = false;
      let startY = 0;
      const handleMouseDown = (e) => {
        if (e.button !== 0) return;
        isDragging = true;
        startY = e.clientY;
        thumb.style.backgroundColor = "#999";
        e.preventDefault();
      };
      const handleMouseMove = (e) => {
        if (!isDragging) return;
        const scrollbar = this._scrollbar;
        const delta = e.clientY - startY;
        const scrollbarHeight = scrollbar.clientHeight;
        const thumbHeight = parseInt(thumb.style.height);
        const maxThumbTop = scrollbarHeight - thumbHeight;
        let newThumbTop = parseInt(thumb.style.top) + delta;
        newThumbTop = Math.max(0, Math.min(newThumbTop, maxThumbTop));
        const totalLines = this._buffer.scrollbackLength + this._buffer.rows;
        const visibleLines = this._buffer.rows;
        const maxScroll = totalLines - visibleLines;
        const newOffset = Math.round((1 - newThumbTop / maxThumbTop) * maxScroll);
        this._buffer.scrollTo(newOffset);
        this._renderer?.setScrollOffset(this._buffer.scrollOffset);
        this._renderer?.markDirty();
        this._renderer?.scheduleRender();
        this._updateScrollbar();
        startY = e.clientY;
      };
      const handleMouseUp = () => {
        isDragging = false;
        thumb.style.backgroundColor = "#666";
      };
      const handleScrollbarClick = (e) => {
        if (isDragging) return;
        if (e.target === thumb) return;
        const scrollbar = this._scrollbar;
        const rect = scrollbar.getBoundingClientRect();
        const clickY = e.clientY - rect.top;
        const thumbHeight = parseInt(thumb.style.height);
        const scrollbarHeight = scrollbar.clientHeight;
        const thumbTop = parseInt(thumb.style.top);
        const totalLines = this._buffer.scrollbackLength + this._buffer.rows;
        const visibleLines = this._buffer.rows;
        const maxScroll = totalLines - visibleLines;
        const clickOffset = Math.round((1 - clickY / scrollbarHeight) * maxScroll);
        this._buffer.scrollTo(Math.max(0, Math.min(clickOffset, maxScroll)));
        this._renderer?.setScrollOffset(this._buffer.scrollOffset);
        this._renderer?.markDirty();
        this._renderer?.scheduleRender();
        this._updateScrollbar();
      };
      thumb.addEventListener("mousedown", handleMouseDown);
      this._scrollbar.addEventListener("click", handleScrollbarClick);
      document.addEventListener("mousemove", handleMouseMove);
      document.addEventListener("mouseup", handleMouseUp);
    }
    /** Dispose of the terminal and clean up resources */
    dispose() {
      this._renderer?.dispose();
      this._inputHandler?.dispose();
      this._eventHandlers.clear();
      if (this._canvas && this._container) {
        this._container.removeChild(this._canvas);
      }
      this._canvas = null;
      this._container = null;
      this._renderer = null;
      this._inputHandler = null;
    }
    // =============================================
    // Parser Callbacks
    // =============================================
    /** Handle printable character */
    _print(char) {
      if (this._cursorX >= this._buffer.cols) {
        if (this._autoWrap) {
          this._cursorX = 0;
          this._cursorY++;
          if (this._cursorY > this._buffer.scrollRegion.bottom) {
            this._cursorY = this._buffer.scrollRegion.bottom;
            this._buffer.scrollUp(1);
          }
        } else {
          this._cursorX = this._buffer.cols - 1;
        }
      }
      if (this._insertMode) {
        this._buffer.insertChars(this._cursorY, this._cursorX, 1);
      }
      this._buffer.setCell(this._cursorX, this._cursorY, {
        char,
        fg: this._currentFg,
        bg: this._currentBg,
        style: { ...this._currentStyle },
        width: 1
      });
      this._cursorX++;
    }
    /** Handle C0 control characters */
    _execute(code) {
      switch (code) {
        case 0:
          break;
        case 7:
          this._emit("bell" /* Bell */);
          break;
        case 8:
          if (this._cursorX > 0) {
            this._cursorX--;
          }
          break;
        case 9:
          this._tab();
          break;
        case 10:
          this._lineFeed();
          break;
        case 11:
          this._lineFeed();
          break;
        case 12:
          this._lineFeed();
          break;
        case 13:
          this._cursorX = 0;
          break;
        case 14:
          break;
        case 15:
          break;
        default:
          break;
      }
    }
    /** Handle CSI sequences */
    _handleCSI(seq) {
      const { prefix, params, intermediates, final } = seq;
      if (prefix === "?") {
        this._handlePrivateModeCSI(params, final);
        return;
      }
      if (prefix === ">") {
        return;
      }
      switch (final) {
        // ---- Cursor Movement ----
        case "A":
          this._cursorUp(this._param(params, 0, 1));
          break;
        case "B":
          this._cursorDown(this._param(params, 0, 1));
          break;
        case "C":
          this._cursorForward(this._param(params, 0, 1));
          break;
        case "D":
          this._cursorBack(this._param(params, 0, 1));
          break;
        case "E":
          this._cursorY = Math.min(this._cursorY + this._param(params, 0, 1), this._buffer.rows - 1);
          this._cursorX = 0;
          break;
        case "F":
          this._cursorY = Math.max(this._cursorY - this._param(params, 0, 1), 0);
          this._cursorX = 0;
          break;
        case "G":
          this._cursorX = Math.max(0, Math.min(this._param(params, 0, 1) - 1, this._buffer.cols - 1));
          break;
        case "H":
        // CUP - Cursor Position
        case "f":
          this._cursorX = Math.max(0, Math.min(this._param(params, 1, 1) - 1, this._buffer.cols - 1));
          this._cursorY = Math.max(0, Math.min(this._param(params, 0, 1) - 1, this._buffer.rows - 1));
          break;
        case "J":
          this._buffer.eraseInDisplay(this._cursorX, this._cursorY, this._param(params, 0, 0));
          break;
        case "K":
          this._buffer.eraseInLine(this._cursorY, this._param(params, 0, 0));
          break;
        case "L":
          this._buffer.insertLines(this._cursorY, this._param(params, 0, 1));
          break;
        case "M":
          this._buffer.deleteLines(this._cursorY, this._param(params, 0, 1));
          break;
        case "P":
          this._buffer.deleteChars(this._cursorY, this._cursorX, this._param(params, 0, 1));
          break;
        case "S":
          this._buffer.scrollUp(this._param(params, 0, 1));
          break;
        case "T":
          this._buffer.scrollDown(this._param(params, 0, 1));
          break;
        case "X":
          const eraseCount = this._param(params, 0, 1);
          for (let i = 0; i < eraseCount; i++) {
            const x = this._cursorX + i;
            if (x >= this._buffer.cols) break;
            this._buffer.setCell(x, this._cursorY, { ...createBlankCell(), fg: this._currentFg, bg: this._currentBg });
          }
          break;
        case "@":
          this._buffer.insertChars(this._cursorY, this._cursorX, this._param(params, 0, 1));
          break;
        case "m":
          this._handleSGR(params);
          break;
        case "r":
          const top = this._param(params, 0, 1) - 1;
          const bottom = this._param(params, 1, this._buffer.rows) - 1;
          if (top >= 0 && bottom < this._buffer.rows && top < bottom) {
            this._buffer.scrollRegion = { top, bottom };
            this._cursorX = 0;
            this._cursorY = this._originMode ? top : 0;
          }
          break;
        case "s":
          this._savedCursorX = this._cursorX;
          this._savedCursorY = this._cursorY;
          this._savedFg = this._currentFg;
          this._savedBg = this._currentBg;
          this._savedStyle = { ...this._currentStyle };
          break;
        case "u":
          this._cursorX = this._savedCursorX;
          this._cursorY = this._savedCursorY;
          this._currentFg = this._savedFg;
          this._currentBg = this._savedBg;
          this._currentStyle = { ...this._savedStyle };
          break;
        case "h":
          this._handleSetMode(params, false);
          break;
        case "l":
          this._handleResetMode(params, false);
          break;
        case "g":
          if (params[0] === 3) {
            this._tabStops = this._tabStops.map(() => false);
          } else if (params[0] === 0 || params.length === 0) {
            if (this._cursorX < this._tabStops.length) {
              this._tabStops[this._cursorX] = false;
            }
          }
          break;
        case "n":
          if (params[0] === 6) {
            this._emit("data" /* Data */, `\x1B[${this._cursorY + 1};${this._cursorX + 1}R`);
          } else if (params[0] === 5) {
            this._emit("data" /* Data */, "\x1B[0n");
          }
          break;
        case "c":
          if (params[0] === 0) {
            this._emit("data" /* Data */, "\x1B[?1;2c");
          }
          break;
        case "q":
          if (intermediates === " ") {
            const style = params[0] || 1;
            switch (style) {
              case 1:
                this._cursorStyle = "block";
                this._cursorBlink = true;
                break;
              case 2:
                this._cursorStyle = "block";
                this._cursorBlink = false;
                break;
              case 3:
                this._cursorStyle = "underline";
                this._cursorBlink = true;
                break;
              case 4:
                this._cursorStyle = "underline";
                this._cursorBlink = false;
                break;
              case 5:
                this._cursorStyle = "bar";
                this._cursorBlink = true;
                break;
              case 6:
                this._cursorStyle = "bar";
                this._cursorBlink = false;
                break;
            }
          }
          break;
        case "d":
          this._cursorY = Math.max(0, Math.min(this._param(params, 0, 1) - 1, this._buffer.rows - 1));
          break;
        default:
          break;
      }
    }
    /** Handle ESC sequences */
    _handleESC(seq) {
      switch (seq.final) {
        case "7":
          this._savedCursorX = this._cursorX;
          this._savedCursorY = this._cursorY;
          this._savedFg = this._currentFg;
          this._savedBg = this._currentBg;
          this._savedStyle = { ...this._currentStyle };
          break;
        case "8":
          this._cursorX = this._savedCursorX;
          this._cursorY = this._savedCursorY;
          this._currentFg = this._savedFg;
          this._currentBg = this._savedBg;
          this._currentStyle = { ...this._savedStyle };
          break;
        case "D":
          this._lineFeed();
          break;
        case "M":
          if (this._cursorY === this._buffer.scrollRegion.top) {
            this._buffer.scrollDown(1);
          } else if (this._cursorY > 0) {
            this._cursorY--;
          }
          break;
        case "E":
          this._cursorX = 0;
          this._lineFeed();
          break;
        case "c":
          this.reset();
          break;
        case "[":
          break;
        default:
          break;
      }
    }
    /** Handle OSC sequences */
    _handleOSC(seq) {
      const { command } = seq;
      const semicolonIndex = command.indexOf(";");
      if (semicolonIndex === -1) return;
      const code = command.substring(0, semicolonIndex);
      const data = command.substring(semicolonIndex + 1);
      switch (code) {
        case "0":
        // Set window title and icon name
        case "1":
        // Set icon name
        case "2":
          this._title = data;
          this._emit("title" /* Title */, data);
          break;
        case "10":
          break;
        case "11":
          break;
        case "52":
          break;
        default:
          break;
      }
    }
    /** Handle SGR (Select Graphic Rendition) - text attributes */
    _handleSGR(params) {
      if (params.length === 0) {
        params = [0];
      }
      for (let i = 0; i < params.length; i++) {
        const p = params[i];
        switch (p) {
          case 0:
            this._currentStyle = {
              bold: false,
              dim: false,
              italic: false,
              underline: false,
              blink: false,
              inverse: false,
              hidden: false,
              strikethrough: false,
              doubleWidth: false
            };
            this._currentFg = -1;
            this._currentBg = -1;
            break;
          case 1:
            this._currentStyle.bold = true;
            break;
          case 2:
            this._currentStyle.dim = true;
            break;
          case 3:
            this._currentStyle.italic = true;
            break;
          case 4:
            this._currentStyle.underline = true;
            break;
          case 5:
            this._currentStyle.blink = true;
            break;
          case 7:
            this._currentStyle.inverse = true;
            break;
          case 8:
            this._currentStyle.hidden = true;
            break;
          case 9:
            this._currentStyle.strikethrough = true;
            break;
          case 22:
            this._currentStyle.bold = false;
            this._currentStyle.dim = false;
            break;
          case 23:
            this._currentStyle.italic = false;
            break;
          case 24:
            this._currentStyle.underline = false;
            break;
          case 25:
            this._currentStyle.blink = false;
            break;
          case 27:
            this._currentStyle.inverse = false;
            break;
          case 28:
            this._currentStyle.hidden = false;
            break;
          case 29:
            this._currentStyle.strikethrough = false;
            break;
          case 30:
          case 31:
          case 32:
          case 33:
          case 34:
          case 35:
          case 36:
          case 37:
            this._currentFg = p - 30;
            break;
          case 38:
            i = this._handleExtendedColor(params, i, false);
            break;
          case 39:
            this._currentFg = -1;
            break;
          case 40:
          case 41:
          case 42:
          case 43:
          case 44:
          case 45:
          case 46:
          case 47:
            this._currentBg = p - 40;
            break;
          case 48:
            i = this._handleExtendedColor(params, i, true);
            break;
          case 49:
            this._currentBg = -1;
            break;
          case 90:
          case 91:
          case 92:
          case 93:
          case 94:
          case 95:
          case 96:
          case 97:
            this._currentFg = p - 90 + 8;
            break;
          case 100:
          case 101:
          case 102:
          case 103:
          case 104:
          case 105:
          case 106:
          case 107:
            this._currentBg = p - 100 + 8;
            break;
          default:
            break;
        }
      }
    }
    /** Handle extended color (256-color and true color) */
    _handleExtendedColor(params, index, isBg) {
      if (index + 1 >= params.length) return index;
      const type = params[index + 1];
      if (type === 5 && index + 2 < params.length) {
        const colorIndex = params[index + 2];
        if (isBg) {
          this._currentBg = colorIndex;
        } else {
          this._currentFg = colorIndex;
        }
        return index + 2;
      }
      if (type === 2 && index + 4 < params.length) {
        const r = params[index + 2];
        const g = params[index + 3];
        const b = params[index + 4];
        const color = [r, g, b];
        if (isBg) {
          this._currentBg = color;
        } else {
          this._currentFg = color;
        }
        return index + 4;
      }
      return index;
    }
    /** Handle private mode CSI sequences (? prefix) */
    _handlePrivateModeCSI(params, final) {
      switch (final) {
        case "h":
          this._handleSetMode(params, true);
          break;
        case "l":
          this._handleResetMode(params, true);
          break;
      }
    }
    /** Handle mode setting */
    _handleSetMode(params, isPrivate) {
      for (const p of params) {
        if (isPrivate) {
          switch (p) {
            case 1:
              this._cursorKeyMode = true;
              break;
            case 3:
              this._columnMode = true;
              break;
            case 6:
              this._originMode = true;
              break;
            case 7:
              this._autoWrap = true;
              break;
            case 12:
              this._cursorBlink = true;
              break;
            case 25:
              this._cursorVisible = true;
              break;
            case 1049:
              this._savedCursorX = this._cursorX;
              this._savedCursorY = this._cursorY;
              break;
          }
        } else {
          switch (p) {
            case 4:
              this._insertMode = true;
              break;
          }
        }
      }
    }
    /** Handle mode resetting */
    _handleResetMode(params, isPrivate) {
      for (const p of params) {
        if (isPrivate) {
          switch (p) {
            case 1:
              this._cursorKeyMode = false;
              break;
            case 3:
              this._columnMode = false;
              break;
            case 6:
              this._originMode = false;
              break;
            case 7:
              this._autoWrap = false;
              break;
            case 12:
              this._cursorBlink = false;
              break;
            case 25:
              this._cursorVisible = false;
              break;
            case 1049:
              this._cursorX = this._savedCursorX;
              this._cursorY = this._savedCursorY;
              break;
          }
        } else {
          switch (p) {
            case 4:
              this._insertMode = false;
              break;
          }
        }
      }
    }
    // =============================================
    // Cursor Movement Helpers
    // =============================================
    _cursorUp(n) {
      const minY = this._originMode ? this._buffer.scrollRegion.top : 0;
      this._cursorY = Math.max(this._cursorY - n, minY);
    }
    _cursorDown(n) {
      const maxY = this._originMode ? this._buffer.scrollRegion.bottom : this._buffer.rows - 1;
      this._cursorY = Math.min(this._cursorY + n, maxY);
    }
    _cursorForward(n) {
      this._cursorX = Math.min(this._cursorX + n, this._buffer.cols - 1);
    }
    _cursorBack(n) {
      this._cursorX = Math.max(this._cursorX - n, 0);
    }
    _tab() {
      for (let x = this._cursorX + 1; x < this._buffer.cols; x++) {
        if (this._tabStops[x]) {
          this._cursorX = x;
          return;
        }
      }
      this._cursorX = this._buffer.cols - 1;
    }
    _lineFeed() {
      if (this._cursorY === this._buffer.scrollRegion.bottom) {
        this._buffer.scrollUp(1);
      } else if (this._cursorY < this._buffer.rows - 1) {
        this._cursorY++;
      }
      this._emit("linefeed" /* LineFeed */);
    }
    // =============================================
    // Utilities
    // =============================================
    /** Get a parameter with default value */
    _param(params, index, defaultValue) {
      return params.length > index && params[index] !== 0 ? params[index] : defaultValue;
    }
    /** Request a render update */
    _requestRender() {
      this._updateScrollbar();
      if (this._renderer) {
        this._renderer.setCursor({
          x: this._cursorX,
          y: this._cursorY,
          visible: this._cursorVisible,
          style: this._cursorStyle,
          blink: this._cursorBlink
        });
        this._renderer.markDirty();
        this._renderer.scheduleRender();
      }
    }
    /** Handle window resize */
    _handleResize() {
    }
    /** Emit an event */
    _emit(event, ...args) {
      this._eventHandlers.get(event)?.forEach((cb) => cb(...args));
    }
  };

  // src/Backend.ts
  var WebSocketBackend = class {
    constructor(terminal, ws) {
      this._attached = false;
      this._dataHandler = null;
      this._openHandler = null;
      this._closeHandler = null;
      this._errorHandler = null;
      /** Handle incoming WebSocket messages */
      this._onMessage = (event) => {
        const data = event.data;
        if (typeof data === "string") {
          this._terminal.write(data);
        } else if (data instanceof ArrayBuffer) {
          this._terminal.write(new Uint8Array(data));
        } else if (data instanceof Blob) {
          data.arrayBuffer().then((buffer) => {
            this._terminal.write(new Uint8Array(buffer));
          });
        }
      };
      this._terminal = terminal;
      this._ws = ws;
    }
    /** Attach the terminal to the WebSocket */
    attach() {
      if (this._attached) return;
      this._attached = true;
      this._dataHandler = (data) => {
        if (this._ws.readyState === WebSocket.OPEN) {
          this._ws.send(data);
        }
      };
      this._terminal.on("data" /* Data */, this._dataHandler);
      this._openHandler = () => {
        this._terminal.focus();
      };
      this._closeHandler = () => {
        this._terminal.write("\r\n\x1B[31m[Connection closed]\x1B[0m\r\n");
      };
      this._errorHandler = (_error) => {
        this._terminal.write("\r\n\x1B[31m[Connection error]\x1B[0m\r\n");
      };
      this._ws.addEventListener("open", this._openHandler);
      this._ws.addEventListener("message", this._onMessage);
      this._ws.addEventListener("close", this._closeHandler);
      this._ws.addEventListener("error", this._errorHandler);
      if (this._ws.readyState === WebSocket.OPEN) {
        this._terminal.focus();
      }
    }
    /** Detach the terminal from the WebSocket */
    detach() {
      if (!this._attached) return;
      this._attached = false;
      if (this._dataHandler) {
        this._terminal.off("data" /* Data */, this._dataHandler);
      }
      if (this._openHandler) {
        this._ws.removeEventListener("open", this._openHandler);
      }
      this._ws.removeEventListener("message", this._onMessage);
      if (this._closeHandler) {
        this._ws.removeEventListener("close", this._closeHandler);
      }
      if (this._errorHandler) {
        this._ws.removeEventListener("error", this._errorHandler);
      }
    }
    /** Send data directly through the WebSocket */
    send(data) {
      if (this._ws.readyState === WebSocket.OPEN) {
        this._ws.send(data);
      }
    }
    /** Get the WebSocket ready state */
    get readyState() {
      return this._ws.readyState;
    }
    /** Check if attached */
    get isAttached() {
      return this._attached;
    }
  };
  var BaseBackend = class {
    constructor() {
      this._terminal = null;
      this._attached = false;
      this._dataHandler = null;
    }
    /** Attach to a terminal */
    attach(terminal) {
      if (this._attached) this.detach();
      this._terminal = terminal;
      this._attached = true;
      this._dataHandler = (data) => {
        this.onInput(data);
      };
      terminal.on("data" /* Data */, this._dataHandler);
      this.onAttach();
    }
    /** Detach from the terminal */
    detach() {
      if (!this._attached) return;
      this.onDetach();
      if (this._dataHandler && this._terminal) {
        this._terminal.off("data" /* Data */, this._dataHandler);
      }
      this._attached = false;
      this._terminal = null;
    }
    /** Write data to the attached terminal (output from backend) */
    write(data) {
      this._terminal?.write(data);
    }
    /** Check if attached */
    get isAttached() {
      return this._attached;
    }
    /** Called when the backend is attached to a terminal */
    onAttach() {
    }
    /** Called when the backend is detached from a terminal */
    onDetach() {
    }
  };
  function attachWebSocket(terminal, url) {
    const ws = new WebSocket(url);
    const backend = new WebSocketBackend(terminal, ws);
    backend.attach();
    return backend;
  }

  // src/PopularFonts.ts
  var POPULAR_MONOSPACE_FONTS = [
    // Web-safe fonts
    "Courier New, Courier, monospace",
    "Consolas, monospace",
    "Menlo, Monaco, monospace",
    "Monaco, monospace",
    "Lucida Console, monospace",
    // Google Fonts & Modern
    "Fira Code, monospace",
    "JetBrains Mono, monospace",
    "Inconsolata, monospace",
    "Source Code Pro, monospace",
    "Roboto Mono, monospace",
    "IBM Plex Mono, monospace",
    "Droid Sans Mono, monospace",
    "Ubuntu Mono, monospace",
    "DejaVu Sans Mono, monospace",
    "Liberation Mono, monospace",
    // Professional/Modern
    "Operator Mono, monospace",
    "Hack, monospace",
    "Anonymous Pro, monospace",
    "Input, monospace",
    "Iosevka, monospace",
    "Fantasque Sans Mono, monospace",
    "Overpass Mono, monospace",
    "Cousine, monospace",
    "Space Mono, monospace",
    "VT323, monospace",
    // Stylish/Trendy
    "SFMono-Regular, SF Mono, monospace",
    "Cascadia Code, monospace",
    "Cascadia Mono, monospace",
    "Noto Sans Mono, monospace",
    "Noto Mono, monospace",
    "Computer Modern, monospace",
    "Courier, monospace",
    "Bitstream Vera Sans Mono, monospace",
    "PT Mono, monospace",
    "Inconsolata for Powerline, monospace",
    // Terminal/System Fonts
    "Terminus, monospace",
    "xterm, monospace",
    "Monospace, monospace",
    "Mono, monospace",
    "Courier 10 Pitch, monospace",
    "Nimbus Mono, monospace",
    "NimbusMono-Regular, monospace",
    "Courier Prime, monospace",
    "Courier Prime Sans, monospace",
    // Gaming/Retro
    "Pixelated, monospace",
    "Perfect DOS VGA 437, monospace",
    "Press Start 2P, monospace"
  ];
  var FONT_CATALOG = [
    {
      name: "Fira Code",
      fallback: "Fira Code, Consolas, monospace",
      description: "Modern, highly legible, excellent for code with ligatures",
      category: "Modern"
    },
    {
      name: "JetBrains Mono",
      fallback: "JetBrains Mono, monospace",
      description: "Professional typeface designed by JetBrains, widely used",
      category: "Professional"
    },
    {
      name: "Consolas",
      fallback: "Consolas, Courier New, monospace",
      description: "Classic Windows code font, very readable",
      category: "Web-safe"
    },
    {
      name: "Source Code Pro",
      fallback: "Source Code Pro, monospace",
      description: "Adobe's monospace font, clean and modern",
      category: "Modern"
    },
    {
      name: "Ubuntu Mono",
      fallback: "Ubuntu Mono, monospace",
      description: "Ubuntu's monospace font, system default on Linux",
      category: "System"
    },
    {
      name: "Courier New",
      fallback: "Courier New, Courier, monospace",
      description: "Classic, widely available web-safe font",
      category: "Web-safe"
    },
    {
      name: "Roboto Mono",
      fallback: "Roboto Mono, monospace",
      description: "Google's modern monospace family",
      category: "Modern"
    },
    {
      name: "IBM Plex Mono",
      fallback: "IBM Plex Mono, monospace",
      description: "IBM's open source monospace font",
      category: "Professional"
    },
    {
      name: "Iosevka",
      fallback: "Iosevka, monospace",
      description: "Highly customizable, versatile monospace font",
      category: "Modern"
    },
    {
      name: "Hack",
      fallback: "Hack, monospace",
      description: "Designed for source code, clear and readable",
      category: "Modern"
    }
  ];
  return __toCommonJS(index_exports);
})();
//# sourceMappingURL=anets-terminal.js.map
